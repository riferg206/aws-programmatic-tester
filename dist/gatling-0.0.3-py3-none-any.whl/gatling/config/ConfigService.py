from configparser import RawConfigParser
import pathlib
import ast


class ConfigService:
    def __init__(self, logger, exception_handler):
        self.logger = logger
        self.session = exception_handler
        self.RawConfigParser = RawConfigParser
        self.ast = ast
        self.path_lib = pathlib.Path
        self.pure_path_lib = pathlib.PurePath
        self.package_path = self.path_lib(__file__).parent.resolve()

    def list_config_files(self, service):
        return [self.pure_path_lib(path).name for path in self.path_lib.iterdir(self.package_path/'configs'/service)]

    def interpolate_config_values(self, arg_name, arg_val):
        args = {}
        type_tag = arg_name[:2]
        if type_tag == "s_":
            strip_val = arg_val.strip("'")
            arg = {arg_name[2:]: strip_val}
            args.update(arg)
        elif type_tag == "i_":
            arg = {arg_name[2:]: int(arg_val)}
            args.update(arg)
        elif type_tag == "b_":
            arg = {arg_name[2:]: bool(arg_val)}
            args.update(arg)
        elif type_tag == "d_":
            nested_val = self.ast.literal_eval(arg_val)
            arg = {arg_name[2:]: nested_val}
            args.update(arg)
        return args

    def parse_config(self, service, config_file):
        parser = self.RawConfigParser()
        parser.optionxform = lambda option: option
        parser.read(f'{self.package_path}/configs/{service}/{config_file}')
        arg_dict = {}
        for section_name in parser.sections():
            for name, value in parser.items(section_name):
                arg_dict.update(self.interpolate_config_values(name, value))
            return arg_dict
