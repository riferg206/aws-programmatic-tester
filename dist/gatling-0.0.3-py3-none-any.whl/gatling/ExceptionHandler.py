class ExceptionHandler:
    def __init__(self, json, logger):
        self.json = json
        self.logger = logger

    def raise_error(self, error_type, message, aws_request_id):
        self.logger.error(f"Error when processing request: {message}")
        response = {
            'errorType': error_type,
            'message': message,
            'awsRequestId': aws_request_id
        }
        raise Exception(self.json.dumps(response))
