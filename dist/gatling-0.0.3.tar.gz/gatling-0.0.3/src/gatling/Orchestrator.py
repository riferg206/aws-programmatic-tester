class Orchestrator:
    def __init__(self, flow_service, session, config_files):
        self.session = session
        self.config_files = config_files
        self.flow_service = flow_service

    def run_config_select_flow(self):
        self.flow_service.run_config_select_flow()
        self.repeat()

    def invoke_flow(self, *config_files):
        run_mthd = input('Welcome to the AWS console tester! Please select a config type from the list below:\n'
                         f'{[mthd for mthd in [attr for attr in dir(self)] if "__" not in mthd]}   ')
        if config_files:
            return getattr(self, run_mthd)()
        else:
            return getattr(self, run_mthd)

    def repeat(self):
        repeat_flow = input('AWS request complete. Would you like to run more tests?:\n'
                            'Y/N?:   ')
        if repeat_flow == 'N':
            exit()
        else:
            self.invoke_flow()
