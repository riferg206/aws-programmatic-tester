from .ExceptionHandler import ExceptionHandler
from .Orchestrator import Orchestrator
from .FlowService import FlowService
from .resources.ResourceMap import ResourceMap
from .config.ConfigService import ConfigService
from boto3 import Session
import logging
import json
import os

_session = Session()
_credentials = _session.get_credentials()
_logger = logging.getLogger()
_logger.setLevel(os.environ['LOG_LEVEL'])
_exception_handler = ExceptionHandler(json, _logger)
_config = ConfigService(_logger, _exception_handler)
_resources = ResourceMap(_logger, _exception_handler, _session)
_flow_service = FlowService(_config, _resources, _session)
_orchestrator = Orchestrator(_flow_service, _session, config_files=None)


def invoke(config_files=None):
    return _orchestrator.invoke_flow(config_files, _session)
