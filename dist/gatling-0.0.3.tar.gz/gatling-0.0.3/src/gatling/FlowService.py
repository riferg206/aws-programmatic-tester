class FlowService:
    def __init__(self, config_service, resource_map, session):
        self.session = session
        self.config_service = config_service
        self.resource_map = resource_map

    def run_config_select_flow(self):
        service_prompt = input(f'{self.resource_map.list_available_services()}\n'
                               f'Please select a service:  ')
        operation = input(f'{self.resource_map.list_service_methods(service_prompt)}\n'
                          f'Please select an operation for your chosen resource {service_prompt}:  ')
        config_file = input(f'{self.config_service.list_config_files(service_prompt)}\n'
                            f'Please select a configuration file from the {service_prompt} directory:  ')
        config_params = self.config_service.parse_config(service_prompt, config_file)
        return self.resource_map.invoke_operation(service_prompt, operation, config_params)

    def run_config_sequential_flow(self, config_files):
        pass

