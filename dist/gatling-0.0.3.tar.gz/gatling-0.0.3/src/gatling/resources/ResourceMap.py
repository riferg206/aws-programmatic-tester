from yaspin import yaspin


class ResourceMap:
    def __init__(self, logger, exception_handler, session):
        self.logger = logger
        self.session = exception_handler
        self.session = session

    def list_available_services(self):
        return self.session.get_available_services()

    def list_service_methods(self, service):
        aws_service = self.session.client(f'{service.lower()}')
        service_methods = aws_service.meta.method_to_api_mapping
        return service_methods

    @staticmethod
    def registered_handler(params, **kwargs):
        pass

    def invoke_operation(self, service, operation, config_params):
        spinner = yaspin(text="Processing request...", color="cyan", timer=True)
        spinner.start()
        aws_service = self.session.client(service)
        event_system = aws_service.meta.events
        api_operation = operation.replace("_", " ").title().replace(" ", "")
        event_system.register(f'provide-client-params.{service}.{api_operation}',
                              ResourceMap.registered_handler)
        op_response = str(print(getattr(aws_service, operation)(**config_params)))
        spinner.write("Processing complete.")
        spinner.stop()
        return op_response
