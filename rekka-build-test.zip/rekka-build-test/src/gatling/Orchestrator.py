class Orchestrator:
    def __init__(self, flow_service, session, config_files):
        self.session = session
        self.config_files = config_files
        self.flow_service = flow_service

    def _run_config_select_flow(self):
        self.flow_service.run_config_select_flow()
        self.repeat()

    def invoke_flow(self, *config_files):
        run_mthd = input('Welcome to the AWS console tester! Please select a config type from the list below:\n'
                         f'{list(filter(lambda func: func.startswith("_") and "__" not in func, dir(self)))}   ')
        if config_files is not None:
            return getattr(self, run_mthd)()
        else:
            return getattr(self, run_mthd)()

    def repeat(self):
        repeat_flow = input('AWS request complete. Would you like to run more tests?:\n'
                            'Y/N?:   ')
        if repeat_flow == 'N':
            return
        else:
            self.invoke_flow()
