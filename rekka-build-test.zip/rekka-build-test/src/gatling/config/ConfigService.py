from configparser import RawConfigParser
from ..Logger import log
import pathlib
import ast


class ConfigService:
    def __init__(self, exception_handler):
        self.session = exception_handler
        self.RawConfigParser = RawConfigParser
        self.path_lib = pathlib.Path
        self.pure_path_lib = pathlib.PurePath
        self.package_path = self.path_lib(__file__).parent.resolve()

    def list_config_files(self, service, operation):
        return [self.pure_path_lib(path).name for path in self.path_lib.iterdir(self.package_path / 'configs'
                                                                                / service / operation)]

    def parse_config(self, config_file):
        parser = self.RawConfigParser()
        parser.optionxform = lambda option: option
        arg_dict = {}
        file = sorted(self.path_lib().rglob(config_file))
        parser.read(f'{self.pure_path_lib(file[0])}')
        parent_path = str(self.pure_path_lib(file[0].parents[0]))
        service, operation = parent_path.split('\\')[4:]
        for section_name in parser.sections():
            for name, value in parser.items(section_name):
                arg_dict.update(self._interpolate_config_values(name, value))
            return service, operation, arg_dict

    @staticmethod
    @log
    def _interpolate_config_values(arg_name, arg_val):
        if arg_val.startswith("\'{"):
            strip_val = arg_val.strip("'")
            return {arg_name: strip_val}
        else:
            raw_val = ast.literal_eval(arg_val)
            return {arg_name: raw_val}
