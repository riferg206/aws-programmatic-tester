from .ExceptionHandler import ExceptionHandler
from .Orchestrator import Orchestrator
from .FlowService import FlowService
from .OptionFlags import OptionFlags
from .resources.ResourceMap import ResourceMap
from .config.ConfigService import ConfigService
from .Logger import log
from boto3 import Session
import json

_session = Session()
_credentials = _session.get_credentials()
_exception_handler = ExceptionHandler(json)
_config = ConfigService(_exception_handler)
_option_flags = OptionFlags()
_resources = ResourceMap(_exception_handler, _session, _option_flags)
_flow_service = FlowService(_config, _resources, _session)
_orchestrator = Orchestrator(_flow_service, _session, config_files=None)


def invoke(*config_files):
    if config_files:
        return _flow_service.run_config_sequential_flow(*config_files)
    else:
        return _orchestrator.invoke_flow(config_files, _session)
