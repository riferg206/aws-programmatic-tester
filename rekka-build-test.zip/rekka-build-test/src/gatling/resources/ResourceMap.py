from yaspin import yaspin
from ..Logger import log


class ResourceMap:
    def __init__(self, exception_handler, session, option_flags):
        self.session = exception_handler
        self.session = session
        self.option_flags = option_flags

    def list_available_services(self):
        return self.session.get_available_services()

    def list_service_methods(self, service):
        aws_service = self.session.client(f'{service.lower()}')
        service_methods = aws_service.meta.method_to_api_mapping
        return service_methods

    @staticmethod
    def registered_handler(params, **kwargs):
        pass

    def invoke_operation(self, service, operation, config_params):
        spinner = yaspin(text="Processing request...", color="cyan", timer=True)
        spinner.start()
        aws_service = self.session.client(service)
        event_system = aws_service.meta.events
        api_operation = operation.replace("_", " ").title().replace(" ", "")
        event_system.register(f'provide-client-params.{service}.{api_operation}',
                              ResourceMap.registered_handler)
        op_response = getattr(aws_service, operation)(**config_params)
        try:
            self.option_flags.decode_b64(op_response.get('LogResult'))
            print(f"\n{self.option_flags.decode_b64(op_response.get('LogResult'))}")
        except TypeError:
            print("LogResult not found.")
        spinner.stop()
        return spinner.write("Processing complete.")
