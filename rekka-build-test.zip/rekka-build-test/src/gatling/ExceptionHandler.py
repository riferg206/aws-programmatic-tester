class ExceptionHandler:
    def __init__(self, json):
        self.json = json

    def raise_error(self, error_type, message, aws_request_id):
        response = {
            'errorType': error_type,
            'message': message,
            'awsRequestId': aws_request_id
        }
        raise Exception(self.json.dumps(response))
